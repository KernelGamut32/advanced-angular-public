import { BadWordsDirective } from './bad-words.directive';

describe('BadWordsDirective', () => {
  it('should create an instance', () => {
    const directive = new BadWordsDirective();
    expect(directive).toBeTruthy();
  });
});
