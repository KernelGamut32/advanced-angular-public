import { OrderHeader } from './order-header.model';

describe('OrderHeader', () => {
  it('should create an instance', () => {
    expect(new OrderHeader()).toBeTruthy();
  });
});
