import { UserRoleDirective } from './user-role.directive';

describe('UserRoleDirective', () => {
  it('should create an instance', () => {
    const directive = new UserRoleDirective();
    expect(directive).toBeTruthy();
  });
});
