export class OrderDetail {
  id: number;
  orderHeaderId: number;
  productNumber: string;
  quantity: number;
  total: number;
}
