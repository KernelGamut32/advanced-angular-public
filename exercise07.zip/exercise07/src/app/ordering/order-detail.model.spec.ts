import { OrderDetail } from './order-detail.model';

describe('OrderDetail', () => {
  it('should create an instance', () => {
    expect(new OrderDetail()).toBeTruthy();
  });
});
